Files submitted in hjl17_Computing.zip:
raytracer.py
test.py
README.txt

Report submitted as:
hjl17_computing.pdf

instructions for how to use test.py are in comments within the file
plot2D and plotXY will plot on the same figure if run at the same time,
so only use 1 at a time. Couldn't figure out how to fix this in time.